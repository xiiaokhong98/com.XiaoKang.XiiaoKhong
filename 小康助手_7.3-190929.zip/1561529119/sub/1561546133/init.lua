template="tool"
name="小康频道"
