name="资源程序"
template="tab"
