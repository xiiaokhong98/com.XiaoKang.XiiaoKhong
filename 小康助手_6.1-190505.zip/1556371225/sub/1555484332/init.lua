template="tool"
name="社交聊天"
