template="tool"
name="游戏活动"
