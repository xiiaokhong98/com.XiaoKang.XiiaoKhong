name="功能助手"
template="tool"
