name="浏览助手"
template="tool"
