sign="30820242308201aba00302010202042c5efc88300d06092a864886f70d01010b05003054310a30080603550406130131310a30080603550408130131310a30080603550407130131310a3008060355040a130131310a3008060355040b130131311630140603550403130d7369676e2e6b657973746f7265301e170d3138303731393136303533305a170d3139303731393136303533305a3054310a30080603550406130131310a30080603550408130131310a30080603550407130131310a3008060355040a130131310a3008060355040b130131311630140603550403130d7369676e2e6b657973746f726530819f300d06092a864886f70d010101050003818d0030818902818100af2a1b8bb426bd9ed437c9f91603ee9b75e9c5f08687a848e0b6bbb7e51314d700cd102cc7e4c33dcc944c5237cc521bccb06807c303676b218637e35e987c96e881af85c729bddee5a6e7c71c5535e00776a461f1baae8c53a727d21db94cf2d8b8d77eeb69f4f3c9e1015e40a9304fba263df30a0178099cacd7badcb441410203010001a321301f301d0603551d0e0416041424faa57eeed403b575b1623b7fcbc2f3efc65a42300d06092a864886f70d01010b0500038181006d9525b9a365c5840c3189496deda14e76fbc3c7be0b6283c44e0f7147856f5902af636d2f777df17fd0077552f81d814daaea2b956e4200d4d6dca1630d9e661a552bb20732e97963846adaaae336b950dfaa21769f95a48a69e05e3562f45ef2d58343d3c21f11d3bfd63e142aa67e19986c2bbd9dc356548246835f925fba"
--v14修复乱七八糟的下载毛病，之前版本有毛病的直接复制本工程里的down.lua文件替换原文件即可。
--v13,仿QQ对话框风格，去除了加载框，增加了强制更新。
--v12修复蓝奏云解析错误
--v9更新对话框动画以及调整了一下布局。增加了备用下载，浏览器下载。
--加点教程吧，免得有些人不会用
--此教程是阿俊(QQ1179416032)综合整合了群里多位大佬教程而成，进制大佬QQ32552732，柯南大佬QQ2947895029。
--1.首先把此工程里的down.lua文件复制到自己的工程目录，函数调用方法看下面的按钮点击事件。
--2.复制链接浏览器打开http://www.iyuji.cn/iyuji/s/MEs4S2gwZkxibHE3ODY4a1FEbjJiUT09/1548204064573247
--3.使用讯飞语记，把链接里的内容替换成你自己链接里的内容
--4.链接内容里的【下载地址】链接【下载地址】换成自己的蓝奏云分享链接
--5.把下面的urla链接换成你的讯飞语记链接
--6.蓝奏云链接格式https://www.lanzous.com/i2ewmje,请注意是文件的分享链接，不是文件夹的。
--阿俊的个人软件群725067128,可以对阿俊的软件提意见，但是不要讨论代码哦，fa群讨论即可。
--希望大家多多支持阿俊自己做的软件哦。(◍˃̶ᗜ˂̶◍)✩
urla="http://www.iyuji.cn/iyuji/s/bjB3dlp1R0tJV3ZKQVB2ajc3aWl1UT09/1562844674449908"
canoffline=false

packinfo=this.getPackageManager().getPackageInfo(this.getPackageName(),((32552732/2/2-8183)/10000-6-231)/9)

appinfo=this.getPackageManager().getApplicationInfo(this.getPackageName(),0)
--名字
applabel=this.getPackageManager().getApplicationLabel(appinfo)
--签名
appsign=tostring(packinfo.signatures[0].toCharsString())
--警告
piracy="您使用的 "..applabel.." 非官方版本，可能已被篡改，为了您设备安全，杜绝木马病毒，请勿运行此版本，如需使用，请下载官方版本"

import "android.content.Context"
function 加载框()
  import "android.graphics.drawable.ColorDrawable"
  import "android.graphics.drawable.ColorDrawable"
  first_lay=
  {
    LinearLayout;
    layout_width="fill";
    orientation="vertical";
    {
      LinearLayout;
      layout_width="120dp";
      layout_height="120dp";
      orientation="vertical";
      id="register";
      layout_gravity='center';
      {
        RelativeLayout;
        layout_width="fill";
        layout_gravity='center';
        layout_height="fill";
        {
          LinearLayout;
          layout_centerHorizontal="true";
          orientation="vertical";
          layout_width="fill";
          layout_marginTop="5%w";
          layout_height="fill";
          {
            SeekBar;
            id="seekbar";
            layout_height="50dp";
            layout_width="50dp";
            layout_gravity='center';
            style="?android:attr/progressBarStyleLarge";
          };
          {
            TextView;
            text="加载中...";
            id="textview";
            layout_marginTop="2.5%w";
            layout_gravity='center';
          };
        };
      };
    };
  }
  import "android.app.AlertDialog"
  local dl=AlertDialog.Builder(activity)
  --.setCancelable(true)
  .setView(loadlayout(first_lay))

  function CircleButton(view,InsideColor,radiu)
    drawable = GradientDrawable() 
    drawable.setShape(GradientDrawable.RECTANGLE) 
    drawable.setColor(InsideColor)
    drawable.setCornerRadii({radiu,radiu,radiu,radiu,radiu,radiu,radiu,radiu});
    view.setBackgroundDrawable(drawable)
  end
  角度=50
  控件id=register
  控件颜色=0xFFFFFFFF
  CircleButton(控件id,控件颜色,角度)

  import "android.graphics.PorterDuffColorFilter"
  import "android.graphics.PorterDuff"
  drawable2 = GradientDrawable(GradientDrawable.Orientation.TR_BL,{
    0xffff5100,--右
    0xffff6e00, --中
    0xffff8f02,--左
  });
  seekbar.IndeterminateDrawable.setColorFilter(PorterDuffColorFilter(0xff2e97ff,PorterDuff.Mode.SRC_ATOP))
  dialog2=dl.show()
  dialog2.getWindow().setBackgroundDrawable(ColorDrawable(0x00000000));
  dialog2.setCancelable(true)
  dialog2.setCanceledOnTouchOutside(false)
  dialog2.setOnCancelListener{
    onCancel=function(l)
      print("取消获取")
    end}
end


function 提示(内容)
  toasts={
    LinearLayout;
    id="toastb";
    {
      TextView;
      background="#FF3C8BDA";
      padding="8dp";
      textSize="15sp";
      TextColor="#ffffffff";
      layout_width="100%w";
      layout_height="40dp";
      gravity="center";
      text="提示出错";
      id="text_ts";
    };
  };
  local toast=Toast.makeText(activity,"内容",Toast.LENGTH_SHORT).setView(loadlayout(toasts))
  --LENGTH_SHORT     2s
  --LENGTH_LONG      3.5s
  toast.setGravity(Gravity.BOTTOM,0, 0)
  --Gravity.BOTTOM   底部
  --Gravity.CENTER   中部
  --Gravity.TOP      顶部
  text_ts.Text=tostring(内容)
  toast.show()
end

Http.get(urla,nil,"UTF-8",nil,function(code,content,cookie,header)
  if(sign==nil or sign=="" or appsign==sign)then
    if(code==200 and content)then
      --过滤
      content=content:gsub("amp;","") or content;
      --content=content:gsub("<br>","\n") or content;
      --content=content:gsub("<div>","") or content;
      --content=content:gsub("</div>","") or content;

      update=content:match("%{更新:(.-):END%}")

      if(update)then
        newest=update:match("%【版本:(.-):END%】")
        qyysize=update:match("%【大小:(.-):END%】")

        if(update:match("%【强制更新:(.-):END%】")=="TRUE")then
          force=true
        else
          force=false
        end
        if(update:match("%【版本号更新:(.-):END%】")=="TRUE" )then
          usevername=true
        else
          usevername=false
        end
        if(usevername)then
          version=tostring(packinfo.versionName)
        else
          version=tostring(packinfo.versionCode)
        end
        chglog=update:match("%【更新日志:(.-):END%】")
        蓝奏云下载链接=content:match("【下载地址】(.-)【下载地址】")
        if not((usevername and version==newest) or (not usevername and version>=newest))then
          --提示("发现新版本，请更新版本")

          yuxuan={--布局
            LinearLayout;
            orientation="vertical";
            Focusable=true,
            FocusableInTouchMode=true,
            {
              Button;--钮扣
              --text="功能菜单";--文本
              --     textSize="25";--文本大小
              textColor="#FFFFFFFF";
              backgroundColor="#FF3C8BDA";--背景色
              id="tuichu";
              layout_width="fill";--宽度
              layout_height="5dp";
            };
            {
              LinearLayout,
              gravity="center";
              layout_width="80%w",
              layout_height="35dp",
              layout_gravity="center";
              {
                TextView;
                textSize="18sp";
                -- layout_marginLeft="5%w";
                textColor="#FF3C8BDA";
                text="发现新版本"..newest,
                gravity="center";
                textStyle="bold",
              };
            },

            {
              LinearLayout,
              orientation="horizontal",
              gravity="center";
              layout_width="fill",
              layout_height="wrap",
              layout_marginBottom="5dp";
              --background="#ffff0000",
              {
                LinearLayout,
                orientation="horizontal",
                gravity="center|left";
                layout_width="40%w",
                layout_height="5%h",

                {
                  TextView;
                  textSize="13sp";
                  layout_marginLeft="5%w";
                  textColor="#FF3C8BDA";
                  text="当前版本: ",
                };
                {
                  TextView;
                  text=version,
                  textSize="13sp";
                  textColor="#FF3C8BDA";
                  id="text1";
                };
              },

              {
                LinearLayout,
                orientation="horizontal",
                gravity="center|right";
                layout_width="40%w",
                layout_height="5%h",
                {
                  TextView;
                  textSize="13sp";
                  textColor="#FF3C8BDA";
                  text="新版大小 : ",
                };
                {
                  TextView;
                  text=qyysize.."mb",
                  layout_marginRight="5%w";
                  textSize="13sp";
                  lines="1",
                  textColor="#FF3C8BDA";
                  id="text2";
                };
              },
            },

            --软件提示信息结束
            { 
              LinearLayout,
              gravity="left";
              layout_width="80%w",
              layout_height="wrap",
              -- background="#fff",
              layout_marginTop="5dp"; 
              --layout_marginBottom="60dp";
              {
                ScrollView, 
                VerticalScrollBarEnabled=false; 
                layout_width="fill";
                layout_height="fill";

                {
                  LinearLayout,
                  orientation="vertical",
                  layout_width="fill";
                  layout_height="fill";
                  id="dc";
                  --更新内容
                  {
                    TextView;
                    textSize="13sp";
                    layout_margin="10dp";
                    textColor="#FF808080";
                    text=chglog,
                    --text=Html.fromHtml(<b>chglog</b>),
                    textStyle="bold",
                    --textScaleX="1.5f",
                  };
                },
              },
            },

            {
              TextView;--钮扣
              text="";--文本
              textSize="15";--文本大小
              textColor="#FF000000";
              layout_width="fill";--宽度
              layout_height="1dp";
              backgroundColor="#FFF3F3F3";--背景色
            };
            {
              LinearLayout;
              gravity="center";
              layout_gravity="center";
              orientation="horizontal";
              layout_width="fill";
              layout_height="45dp";
              {
                TextView;
                gravity="center";
                layout_width="45%w";
                textColor="#ff000000";
                text="浏览器更新";
                id="sj";
                 style="?android:attr/buttonBarButtonStyle";
                textSize="15";
              };
              {
                TextView;--钮扣
                text="";--文本
                textSize="15";--文本大小
                textColor="#FF000000";
                layout_width="1dp";--宽度
                layout_height="-1";
                backgroundColor="#FFF3F3F3";--背景色
              };

              {
                TextView;
                gravity="center";
                layout_width="45%w";
                textColor="#ff000000";
                text="立即更新";
                id="sj1";
                 style="?android:attr/buttonBarButtonStyle";
                textSize="15";
              };
            };

          }

          --text2.text=qyysize

          update_dialog= LuaDialog(this)
          import "android.text.SpannableString"
          import "android.text.style.ForegroundColorSpan"
          import "android.text.Spannable"
          update_dialog.show()
          update_dialog.getWindow().setContentView(loadlayout(yuxuan));    
          update_dialog.setCanceledOnTouchOutside(false)
          update_dialog.setCancelable(false)--
          import "android.graphics.drawable.ColorDrawable"
          --   dialog1.getWindow().setBackgroundDrawable(ColorDrawable(0x00000000));




          sj.onClick=function(v)
            update_dialog.dismiss()
            
            import "android.content.Intent"
            import "android.net.Uri"
            url=蓝奏云下载链接
            viewIntent = Intent("android.intent.action.VIEW",Uri.parse(url))
            activity.startActivity(viewIntent)
            提示"浏览器下载"
            退出页面()
          end
          sj1.onClick=function(v)

            update_dialog.dismiss() --关闭更新弹窗
   
            import"down2"
            提示("更新若失败请尝试浏览器更新")
        蓝奏云直链(蓝奏云下载链接)
    
          end

        else 
          --dialog2.dismiss()
          --提示("已是最新版")
          return true
        end 
      else
        return true 
      end
    else
      if(code==-1)then
        --dialog2.dismiss()
        弹出消息("无法连接网络，请检查您的网络设置")
      else
        -- dialog2.dismiss()
        弹出消息("网络请求失败".." "..code)
      end
      return (canoffline or 退出程序())
    end
  else
    if(code==200 and content )then
      print("非法修改软件")
      退出程序()
  end
end
end)