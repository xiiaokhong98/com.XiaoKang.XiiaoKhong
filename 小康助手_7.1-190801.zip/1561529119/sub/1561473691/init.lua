template="tool"
name="功能助手"
