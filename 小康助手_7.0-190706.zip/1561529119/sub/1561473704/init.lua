template="tool"
name="浏览助手"
