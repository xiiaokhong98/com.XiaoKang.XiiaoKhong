name="关于小康助手"
template="tool"
