name="检查更新"
template="blank"
