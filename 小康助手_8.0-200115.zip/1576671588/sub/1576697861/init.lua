template="tool"
name="11 轻浏览器"
